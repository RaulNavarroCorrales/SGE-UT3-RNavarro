To configure this module, you need to:

1. Set the probabilities on the stages
2. Run the "Update leads probability" wizard on the stages to update
