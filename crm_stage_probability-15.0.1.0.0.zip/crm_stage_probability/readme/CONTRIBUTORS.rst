* Odoo SA
* Akim Juillerat <akim.juillerat@camptocamp.com>
* Robin Goots <robin.goots@dynapps.be>
