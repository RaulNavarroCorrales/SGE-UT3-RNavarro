This module restore the CRM feature from Odoo \<= 12.0 with lead
probability according to its stage.
